import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Scanner;

public class Principal {
    private static final String URL_MYSQL = "jdbc:mysql://localhost:3306/Fitlife";
    private static final String USER = "root";
    private static final String PASSWORD = "Cecilia.200";  //mi contraseña


    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            // para establecer la conexión
            Connection dbConn = DriverManager.getConnection(URL_MYSQL, USER, PASSWORD);

            // solicitar la info del socio
            System.out.print("Dni del socio: ");
            String dni = scanner.nextLine();
            System.out.print("Nombre del socio: ");
            String nombre = scanner.nextLine();
            System.out.print("Primer apellido: ");
            String primerApellido = scanner.nextLine();
            System.out.print("Segundo apellido (si aplica): ");
            String segundoApellido = scanner.nextLine();
            System.out.print("Teléfono: ");
            String telefono = scanner.nextLine();
            System.out.print("Email: ");
            String email = scanner.nextLine();
            System.out.print("Dirección: ");
            String direccion = scanner.nextLine();

            // insertar el nuevo socio en la base de datos
            String insertSQL = "INSERT INTO Socio (Dni_socio, Nombre_socio, Primer_apellido, Segundo_apellido, Telefono_socio, Email_socio, Direccion_socio) "
                    + "VALUES (?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement pstmt = dbConn.prepareStatement(insertSQL);
            pstmt.setString(1, dni);
            pstmt.setString(2, nombre);
            pstmt.setString(3, primerApellido);
            pstmt.setString(4, segundoApellido);
            pstmt.setString(5, telefono);
            pstmt.setString(6, email);
            pstmt.setString(7, direccion);
            pstmt.executeUpdate();

            System.out.println("Socio añadido correctamente.");

            // Cerrar recursos
            pstmt.close();
            dbConn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
